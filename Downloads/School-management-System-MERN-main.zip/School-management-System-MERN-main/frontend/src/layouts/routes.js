export const teacherRoutes = [
    {
        path: "/dashboard",
        name: "Dashboard",
        icon: " icon-chart-pie-36",
        component: "Dashboard",
        layout: "/admin"
    },
    {
        path: "/dashboard",
        name: "Dashboard",
        icon: " icon-chart-pie-36",
        component: "Dashboard",
        layout: "/admin"
    },
    {
        path: "/dashboard",
        name: "Dashboard",
        icon: " icon-chart-pie-36",
        component: "Dashboard",
        layout: "/admin"
    },
    
]


export const adminRoutes =  [
    {
        path: "/dashboard",
        name: "Dashboard",
        icon: " icon-chart-pie-36",
        component: "Dashboard",
        layout: "/admin"
    },
    {
        path: "/students",
        name: "Students",
        icon: " icon-chart-pie-36",
        component: "Students",
        layout: "/admin"
    },
    {
        path: "/teachers",
        name: "Staff",
        icon: " icon-chart-pie-36",
        component: "Teachers",
        layout: "/admin"
    },
    {
        path: "/academics",
        name: "Academics",
        icon: " icon-chart-pie-36",
        component: "Academics",
        layout: "/admin"
    },
    {
        path: "/Finance",
        name: "Finance",
        icon: " icon-chart-pie-36",
        component: "Finance",
        layout: "/admin"
    },
    {
        path: "/messages",
        name: "Messages",
        icon: " icon-chart-pie-36",
        component: "Messages",
        layout: "/admin"
    },
]