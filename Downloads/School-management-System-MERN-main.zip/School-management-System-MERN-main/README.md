# School-management-System-MERN

### school management system for schools

School Management System built on MERN stack (Mongo, React/Redux, Node).

##### http://demo.dtechghana.com/serp

we need all features from above url

##### https://preview.themeforest.net/item/akkhor-school-management-admin-template/full_screen_preview/23687250?_ga=2.255758081.864210670.1612108516-299139616.1603134458

and will use this template design
