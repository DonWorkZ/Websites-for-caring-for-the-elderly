export const role = {
    Student: "student",
    Teacher: "teacher",
    NonTeacher: "nonteacher"
}
